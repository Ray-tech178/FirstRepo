import UIKit

var part1 = "Knock Knock" + "\n" + "Who's there" + "\n" + "Ima" + "\n" + "Ima who" + "\n" + "Ima about to knock on your door again"
print(part1)
