import UIKit

var joke = "When I get pain I tell my mom it hertz!"
print(joke)
